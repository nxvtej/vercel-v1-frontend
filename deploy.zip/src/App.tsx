/** @format */

import "./App.css";
import { Landing } from "./components/landing";

function App() {
	return <Landing />;
}

export default App;
