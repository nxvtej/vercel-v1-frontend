/** @format */

const Landing = () => {
	return (
		<div className=''>
			<div>Landing</div>
		</div>
	);
};

export default Landing;
